﻿namespace PlayersAndMonsters.Core
{
    using System;
    using System.Linq;
    using System.Text;
    using Contracts;
    using PlayersAndMonsters.Common;
    using PlayersAndMonsters.Models.BattleFields;
    using PlayersAndMonsters.Models.BattleFields.Contracts;
    using PlayersAndMonsters.Models.Cards;
    using PlayersAndMonsters.Models.Cards.Contracts;
    using PlayersAndMonsters.Models.Players;
    using PlayersAndMonsters.Models.Players.Contracts;
    using PlayersAndMonsters.Repositories;
    using PlayersAndMonsters.Repositories.Contracts;

    public class ManagerController : IManagerController
    {
        private IPlayerRepository playerRepository;
        private ICardRepository cardRepository;
        private IBattleField battleField;

        public ManagerController()
        {
            this.playerRepository = new PlayerRepository();
            this.cardRepository = new CardRepository();
            this.battleField = new BattleField();
        }

        public string AddPlayer(string type, string username)
        {
            if (type == "Beginner")
            {

                IPlayer player = new Beginner(cardRepository, username);
                playerRepository.Add(player);
            }
            if(type== "Advanced")
            {
                IPlayer player = new Advanced(cardRepository, username);
                playerRepository.Add(player);
            }
            return string.Format(ConstantMessages.SuccessfullyAddedPlayer, type, username);
        }
        public string AddCard(string type, string name)
        {
            if (type == "Magic")
            {

                ICard card = new MagicCard(name);
                cardRepository.Add(card);
            }
            if (type == "Trap")
            {
                ICard card = new TrapCard(name);
                cardRepository.Add(card);
            }
            return string.Format(ConstantMessages.SuccessfullyAddedCard, type, name);

        }

        public string AddPlayerCard(string username, string cardName)
        {
            var player =this.playerRepository.Find(username);
            var card =this.cardRepository.Find(cardName);
            player.CardRepository.Add(card);
            return string.Format(ConstantMessages.SuccessfullyAddedPlayerWithCards, cardName, username);
        }
        public string Fight(string attackUser, string enemyUser)
        {
            var attackPlayer =this.playerRepository.Find(attackUser);
            var enemyPlayer = this.playerRepository.Find(enemyUser);
            this.battleField.Fight(attackPlayer, enemyPlayer);
            return string.Format(ConstantMessages.FightInfo, attackPlayer.Health, enemyPlayer.Health);
        }
        public string Report()
        {
            StringBuilder result = new StringBuilder();
            foreach (var player in playerRepository.Players)
            {
                result.AppendLine
                    (string.Format(ConstantMessages.PlayerReportInfo,
                    player.Username, player.Health, player.CardRepository.Cards.Count));
                foreach (var card in player.CardRepository.Cards)
                {
                    result.AppendLine(string.Format(ConstantMessages.CardReportInfo, card.Name, card.DamagePoints));
                }
                result.AppendLine(ConstantMessages.DefaultReportSeparator);
            }
            return result.ToString().TrimEnd();
        }
    }
}
