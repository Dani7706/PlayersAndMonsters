﻿using PlayersAndMonsters.Core.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace PlayersAndMonsters.Core
{
    public class Engine : IEngine
    {
        private IManagerController managerController;

        public Engine(IManagerController managerController)
        {
            this.managerController = managerController;
        }

        public void Run()
        {
            string input = "";
            string result = "";
            while (input !="Exit")
            {
                input = Console.ReadLine();
                if (input == "Exit")
                {
                    break;
                }
                string[] commandArgs = input.Split();
                string command = commandArgs[0];
                try
                {
                    switch (command)
                    {
                        case "AddPlayer":
                            string playerType = commandArgs[1];
                            string playerUserName = commandArgs[2];
                            result = managerController.AddPlayer(playerType, playerUserName);
                            break;
                        case "AddCard":
                            string cardType = commandArgs[1];
                            string cardUserName = commandArgs[2];
                            result = managerController.AddCard(cardType, cardUserName);
                            break;
                        case "AddPlayerCard":
                            string userName = commandArgs[1];
                            string cardName = commandArgs[2];
                            result = managerController.AddPlayerCard(userName, cardName);
                            break;
                        case "Fight":
                            string attackUser = commandArgs[1];
                            string enemyUser = commandArgs[2];
                            result = managerController.Fight(attackUser, enemyUser);
                            break;
                        case "Report":
                            result = managerController.Report();
                            break;
                        default:
                            break;
                    }

                }
                catch (Exception e)
                {

                    Console.WriteLine(e.Message);
                }
                Console.WriteLine(result);
            }
        }
    }
}
