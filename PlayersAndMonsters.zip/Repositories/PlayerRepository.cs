﻿using PlayersAndMonsters.Models.Players.Contracts;
using PlayersAndMonsters.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace PlayersAndMonsters.Repositories
{
    public class PlayerRepository : IPlayerRepository
    {
        private readonly List<IPlayer> players;

        public PlayerRepository()
        {
            players = new List<IPlayer>();
        }

        public int Count { get; }

        public IReadOnlyCollection<IPlayer> Players => this.players.AsReadOnly();

        public void Add(IPlayer player)
        {
            if (player == null)
            {
                throw new ArgumentException("Player cannot be null");
            }
            if (players.FirstOrDefault(x => x.Username == player.Username)!=null)
            {
                throw new ArgumentException($"Player {player.Username} already exists!");
            }
            players.Add(player);
        }

        public IPlayer Find(string username)
        {
            var player = players.FirstOrDefault(x => x.Username == username);
            return player;

        }

        public bool Remove(IPlayer player)
        {
            if (player == null)
            {
                throw new ArgumentException("Player cannot be null");
            }
            return players.Remove(player);
        }
    }
}
